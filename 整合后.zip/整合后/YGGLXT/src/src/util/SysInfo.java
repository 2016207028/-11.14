package src.util;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.ResourceBundle;
import javax.servlet.ServletContext;

/**
 * 系统基础信息
 * 
 * @author wzy
 */
public class SysInfo {

	private String REAL_PATH;// 工程物理路径
	private String PATH;// 工程地址
	private String projectName;// 工程名
	private ServletContext sct;

	public String toXMLString() {
		return "<object projectName='" + projectName + "' REAL_PATH='" + REAL_PATH + "'  PATH='" + PATH + "'/>";
	}

	public SysInfo(ServletContext sct) {
		this.sct = sct;
		ResourceBundle bundle = ResourceBundle.getBundle("set");// 加载配置文件
		this.REAL_PATH = sct.getRealPath("").replaceAll("\\\\", "/") + "/";// 工程物理路径
		this.PATH = "/" + sct.getContextPath().substring(1) + "/";
		sct.setAttribute("REAL_PATH", REAL_PATH);// 工程物理路径
		sct.setAttribute("path", PATH);// 工程名

		// 汉字描述工程名
		try {
			this.projectName = new String(bundle.getString("projectName").getBytes("iso-8859-1"), "utf-8");
			// if (!"".equals(ocrUrl)) {
			// ocrUrl = ocrUrl.replaceAll("\\", "\\\\");
			// }
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			this.projectName = "";
		}
		sct.setAttribute("projectName", this.projectName);
		sct.setAttribute("onlineUser", new HashMap<String, String>());// 在线客服<dm_userkind,登陆时的key>

		// 提示信息
		System.out.println("\n*****************************************");
		System.out.println("工程名称：" + sct.getAttribute("projectName"));
		System.out.println("工程名：" + sct.getAttribute("path"));
		System.out.println("工程文件物理路径：" + sct.getAttribute("REAL_PATH"));
		System.out.println("*******************************************\n");
	}

	public String getREAL_PATH() {
		return REAL_PATH;
	}

	public String getProjectName() {
		return projectName;
	}

	public ServletContext getSct() {
		return sct;
	}

	public String getPATH() {
		return PATH;
	}

}
