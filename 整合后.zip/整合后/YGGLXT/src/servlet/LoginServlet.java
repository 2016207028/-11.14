package servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Hashtable;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.PublicCmd;

import src.util.PublicUtil;

@SuppressWarnings({ "rawtypes", "serial" })
public class LoginServlet extends BaseServlet {

	// 登录
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("login_", request);
		String sql = "select t.*,a.bmmc as bm,b.js as jsmc from yhb t left join bmb a on t.bmid=a.id left join jsb b on b.id=t.js where 1=1 ";// 查询sql语句
		String name = (String) ht.get("YHM");// 用户名
		// 特殊字符简单处理
		name = name.replace("'", "''");
		name = name.replace(" ", "");

		String pwdInput = (String) ht.get("MM");// 密码
		sql = sql + " and yhm='" + name + "'";
		Hashtable returuser = PublicCmd.find_OneObject(sql);// 根据用户名查询条数据

		if (null == returuser || returuser.isEmpty()) {
			// 查询有无用户
			String message = "用户不存在，请重新输入！";
			request.setAttribute("message", message);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('" + message + "');window.history.go(-1);</script>");
		} else {
			// 存在用户，检测密码是否正确
			if (pwdInput.equals((String) returuser.get("MM"))) {
				request.getSession().setAttribute("login_user", returuser);
				response.sendRedirect(request.getContextPath() + "/frame.jsp");
			} else {
				// 密码错误，跳转重新登录
				String message = "密码输入错误，请重新输入！";
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print(
						"<script type='text/javascript'>alert('" + message + "');window.history.go(-1);</script>");
			}
		}

	}

	// 保存个人信息
	public void savegrxx(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 文件上传
		String id = request.getParameter("id");
		String yhm = request.getParameter("yhm")==null?"":request.getParameter("yhm");
		String xpwd = request.getParameter("xpwd")==null?"":request.getParameter("xpwd");
		String xm = request.getParameter("xm")==null?"":request.getParameter("xm");
		
		String sql = "update yhb set yhm='" + yhm + "',xm='" + xm + "' ";

		if (!"".equals(xpwd) && xpwd != null) {
			sql = sql + ",mm='" + xpwd + "' ";
		}
		sql = sql + " where id=" + id;
		String message = "";
		if (PublicCmd.update(sql)) {
			message = "修改成功！";
			response.setContentType("text/html;charset=utf-8");
			String usersql = "select t.*,a.bmmc as bm,b.js as jsmc from yhb t left join bmb a on t.bmid=a.id left join jsb b on b.id=t.js where t.id="
					+ id;// 查询sql语句
			Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据用户名查询条数据
			request.setAttribute("message", message);
			request.getSession().setAttribute("login_user", returuser);//session会话刷新
			response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
					+ request.getContextPath() + "/grxx.jsp'</script>");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('修改失败，请重试');window.history.go(-1);</script>");
		}
	}

	public void exit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flag = request.getParameter("flag");// flag
		request.getSession().removeAttribute("login_user");
		if ("ht".equals(flag)) {
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print("<script type='text/javascript'>alert('注销成功');" + "location='"
					+ request.getContextPath() + "/LoginServlet?action=Index'</script>");
		}
	}
}
