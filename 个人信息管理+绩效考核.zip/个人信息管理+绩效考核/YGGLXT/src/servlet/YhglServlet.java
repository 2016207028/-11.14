package servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.Page;
import com.util.PublicCmd;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 用户管理
 * 
 * @author wzy 2018-04-28
 */
@SuppressWarnings({ "serial", "rawtypes", "unused" })
public class YhglServlet extends BaseServlet {
	// 操作标志
	private String flag = "";

	// 查询用户信息
	public void find(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录用户信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		// 获取页面查询条件
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("find_yhgl_", request);

		// 获取排序条件
		String pxtj = "";
		String cxtj = "";
		if (ht != null) {
			String yhm = ht.get("YHM") == null ? "" : (String) ht.get("YHM");
			String xm = ht.get("XM") == null ? "" : (String) ht.get("XM");
			if (!"".equals(yhm)) {
				pxtj = pxtj + " and yhm='" + yhm + "'";
				cxtj = cxtj + "&yhm=" + yhm;
			}

			if (!"".equals(xm)) {
				pxtj = pxtj + " and xm like'%" + xm + "%'";
				cxtj = cxtj + "&xm=" + xm;
			}
		} else {
			String yhm = request.getParameter("yhm") == null ? "" : request.getParameter("yhm");
			String xm = request.getParameter("xm") == null ? "" : request.getParameter("xm");
			if (!"".equals(yhm)) {
				pxtj = pxtj + " and yhm='" + yhm + "'";
				cxtj = cxtj + "&yhm=" + yhm;
			}

			if (!"".equals(xm)) {
				pxtj = pxtj + " and xm like'%" + xm + "%'";
				cxtj = cxtj + "&xm=" + xm;
			}
		}
		// 角色
		if ("1".equals(hasuser.get("JS"))) {

		} else if ("2".equals(hasuser.get("JS"))) {
			pxtj = pxtj + " and bmid=" + hasuser.get("BMID") + " and t.js=3 ";
		}

		String indexKey = "id";// 排序关键
		String sort = " desc ";
		// 查询信息
		String sql = "select t.id,t.yhm as yhm,t.xm as xm,t.xb,t.csny,t.dh,a.bmmc as bm,b.js as jsmc from yhb t left join bmb a on t.bmid=a.id left join jsb b on b.id=t.js where 1=1 "
				+ pxtj;

		/* 分页 */
		String sql0 = "select count(1) from (" + sql + ") cona";
		int size = 0;
		if ("-2".equals(PublicCmd.find_returnOne(sql0))) {
			size = 0;
		} else {
			size = Integer.parseInt(PublicCmd.find_returnOne(sql0));
		}
		long curPage = 0l;
		if (null == request.getParameter("curPage") || "".equals(request.getParameter("curPage"))) {
			curPage = 1l;
		} else {
			curPage = Long.parseLong(request.getParameter("curPage"));
		}
		int pageSize = 8;

		String types = "mysql";
		sql = Page.getSql(sql, curPage, pageSize, indexKey, sort, types);
		String target = request.getContextPath() + "/servlet/YhglServlet?action=find&flag=" + flag + cxtj + "&";
		String linkStr = Page.getPagestr(size, pageSize, curPage, target);
		request.setAttribute("linkStr", linkStr);
		/* 分页 */
		ArrayList yhgl_arr = PublicCmd.find_allObject(sql);
		request.setAttribute("yhgl_arr", yhgl_arr);

		request.getRequestDispatcher("/yhgl.jsp").forward(request, response);
	}

	// 信息初始化跳转
	public void intxxedit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 当前登录用户信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		request.setAttribute("flag", flag);
		// 查询部门信息
		String bmsql = "select id,bmmc from bmb where 1=1 ";
		if ("1".equals(hasuser.get("JS"))) {

		} else {
			bmsql = bmsql + " and id=" + hasuser.get("BMID");
		}
		ArrayList bmlist = PublicCmd.find_allObject(bmsql);
		String bmoptions = "";
		for (int i = 0; i < bmlist.size(); i++) {
			Hashtable bmht = (Hashtable) bmlist.get(i);
			bmoptions = bmoptions + "<option value='" + bmht.get("ID") + "'>" + bmht.get("BMMC") + "</option>";
		}
		request.setAttribute("bmoptions", bmoptions);
		// String id = (String) request.getAttribute("ID");
		String id = request.getParameter("id") == null ? "" : request.getParameter("id");
		if (!"".equalsIgnoreCase(id)) {
			String sql = "select t.* from yhb t where t.id=" + id;
			Hashtable ht = PublicCmd.find_OneObject(sql);
			request.setAttribute("rbht", ht);
		} else {
		}
		request.getRequestDispatcher("/yhedit.jsp").forward(request, response);
	}

	// 保存个人信息
	public void saveyhxx(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		String xpwd = request.getParameter("xpwd");
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("up_grxx_", request);
		if ("0".equals(id)) {
			String countsql = "select count(1) from yhb t where t.yhm='" + ht.get("YHM") + "' ";
			String co = PublicCmd.find_returnOne(countsql);
			if ("0".equals(co))// 用户名不重复，可以注册
			{
				ht.put("MM", xpwd);
				if (PublicCmd.insert_returnflag(ht, "yhb")) {
					response.setContentType("text/html;charset=utf-8");
					response.getWriter().print("<script type='text/javascript'>alert('保存成功');" + "location='"
							+ request.getContextPath() + "/yhgl.jsp?loadbz=load'</script>");
				} else {

					response.setContentType("text/html;charset=utf-8");
					response.getWriter()
							.print("<script type='text/javascript'>alert('保存失败，请重试');window.history.go(-1);</script>");
				}
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print(
						"<script type='text/javascript'>alert('保存，用户名已存在，请修改后重试');window.history.go(-1);</script>");
			}
		} else {
			String sql = "update yhb set xm='" + ht.get("XM") + "',xb='" + ht.get("XB") + "',csny='" + ht.get("CSNY")
					+ "',dh='" + ht.get("DH") + "',bmid='" + ht.get("BMID") + "',js='" + ht.get("JS") + "' ";
			if (!"".equals(xpwd) && xpwd != null) {
				sql = sql + ",pwd='" + xpwd + "' ";
			}
			sql = sql + " where id=" + id;
			String message = "";
			if (PublicCmd.update(sql)) {
				message = "修改成功！";
				String usersql = "select * from yhb where id=" + id;// 查询sql语句
				Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据用户名查询条数据
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
						+ request.getContextPath() + "/yhgl.jsp?loadbz=load'</script>");
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter()
						.print("<script type='text/javascript'>alert('修改失败，请重试');window.history.go(-1);</script>");
			}
		}
	}

	// 信息审核初始化跳转
	public void intsh(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录用户信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		request.setAttribute("flag", flag);
		// String id = (String) request.getAttribute("ID");
		String id = request.getParameter("id") == null ? "" : request.getParameter("id");
		if (!"".equalsIgnoreCase(id)) {
			String sql = "select t.* from yhb t where t.id=" + id;
			Hashtable ht = PublicCmd.find_OneObject(sql);
			request.setAttribute("rbht", ht);
		} else {
		}
		request.getRequestDispatcher("/yhsh.jsp").forward(request, response);
	}

	public void saveyhsh(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		String bz = request.getParameter("bz");
		String shyj = request.getParameter("shyj");
		String sql = "update yhb set bz='" + bz + "',shyj='" + shyj + "'";
		sql = sql + " where id=" + id;
		String message = "";
		if (PublicCmd.update(sql)) {
			message = "审核成功！";
			String usersql = "select * from yhb where id=" + id;// 查询sql语句
			Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据用户名查询条数据
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
					+ request.getContextPath() + "/yhgl.jsp?loadbz=load'</script>");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('审核失败，请重试');window.history.go(-1);</script>");
		}
	}

	public void delxx(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		String flag = request.getParameter("flag");
		String updatesql = "";
		if ("del".equals(flag)) {
			String sql = "delete from  yhb ";
			sql = sql + " where id=" + id;
			String message = "";
			if (PublicCmd.update(sql)) {
				message = "删除成功！";
				String usersql = "select * from yhb where id=" + id;// 查询sql语句
				Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据用户名查询条数据
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
						+ request.getContextPath() + "/yhgl.jsp?loadbz=load'</script>");
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter()
						.print("<script type='text/javascript'>alert('删除失败，请重试');window.history.go(-1);</script>");
			}

		} else {
			String sql = "update yhb set mm='1' ";
			sql = sql + " where id=" + id;
			String message = "";
			if (PublicCmd.update(sql)) {
				message = "密码重置成功！";
				String usersql = "select * from yhb where id=" + id;// 查询sql语句
				Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据用户名查询条数据
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
						+ request.getContextPath() + "/yhgl.jsp?loadbz=load'</script>");
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter()
						.print("<script type='text/javascript'>alert('密码重置失败，请重试');window.history.go(-1);</script>");
			}

		}
	}

	// 查询网络上的文件是否存在
	public boolean getRource(String source) {
		try {
			URL url = new URL(source);
			URLConnection uc = url.openConnection();
			InputStream in = uc.getInputStream();
			if (source.equalsIgnoreCase(uc.getURL().toString()))
				in.close();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// 数据流写入
	public static byte[] readInputStream(InputStream inStream) throws Exception {
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		// 创建一个Buffer字符串
		byte[] buffer = new byte[1024];
		// 每次读取的字符串长度，如果为-1，代表全部读取完毕
		int len = 0;
		// 使用一个输入流从buffer里把数据读取出来
		while ((len = inStream.read(buffer)) != -1) {
			// 用输出流往buffer里写入数据，中间参数代表从哪个位置开始读，len代表读取的长度
			outStream.write(buffer, 0, len);
		}
		// 关闭输入流
		inStream.close();
		// 把outStream里的数据写入内存
		return outStream.toByteArray();
	}

}
